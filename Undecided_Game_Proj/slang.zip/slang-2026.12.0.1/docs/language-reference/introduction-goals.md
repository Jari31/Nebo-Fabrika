# Slang Language Goals

TODO
