#
# Given a list of flags, add those which the C++ compiler supports to the target
#
include(CheckCXXCompilerFlag)
function(add_supported_cxx_flags target)
    cmake_parse_arguments(ARG "PRIVATE;PUBLIC;INTERFACE" "" "" ${ARGN})
    set(flags ${ARG_UNPARSED_ARGUMENTS})
    if(ARG_PRIVATE)
        set(private PRIVATE)
    endif()
    if(ARG_PUBLIC)
        set(public PUBLIC)
    endif()
    if(ARG_INTERFACE)
        set(interface INTERFACE)
    endif()

    foreach(flag ${flags})
        # remove the `no-` prefix from warnings because gcc doesn't treat it as an
        # error on its own
        string(REGEX REPLACE "\\-Wno\\-(.+)" "-W\\1" flag_to_test "${flag}")
        string(
            REGEX REPLACE
            "[^a-zA-Z0-9]+"
            "_"
            test_name
            "CXXFLAG_${flag_to_test}"
        )
        check_cxx_compiler_flag("${flag_to_test}" ${test_name})
        if(${test_name})
            target_compile_options(
                ${target}
                ${private}
                ${public}
                ${interface}
                ${flag}
            )
        endif()
    endforeach()
endfunction()

#
# Given a list of linker flags, add those which the compiler supports to the
# target
#
include(CheckLinkerFlag)
function(add_supported_cxx_linker_flags target)
    cmake_parse_arguments(ARG "PRIVATE;PUBLIC;INTERFACE;BEFORE" "" "" ${ARGN})
    set(flags ${ARG_UNPARSED_ARGUMENTS})
    if(ARG_BEFORE)
        set(before BEFORE)
    endif()
    if(ARG_PRIVATE)
        set(private PRIVATE)
    endif()
    if(ARG_PUBLIC)
        set(public PUBLIC)
    endif()
    if(ARG_INTERFACE)
        set(interface INTERFACE)
    endif()

    foreach(flag ${flags})
        string(
            REGEX REPLACE
            "[^a-zA-Z0-9]+"
            "_"
            test_name
            "CXXLINKFLAG_${flag}"
        )
        check_linker_flag(CXX "${flag}" ${test_name})
        if(${test_name})
            target_link_options(
                ${target}
                ${before}
                ${private}
                ${public}
                ${interface}
                ${flag}
            )
        endif()
    endforeach()
endfunction()

#
# Add our default compiler flags to a target
#
# Pass USE_EXTRA_WARNINGS to enable -WExtra or /W3
#
function(set_default_compile_options target)
    cmake_parse_arguments(
        ARG
        "USE_EXTRA_WARNINGS;USE_FEWER_WARNINGS;SKIP_ASAN"
        ""
        ""
        ${ARGN}
    )

    set(warning_flags)
    if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
        list(
            APPEND
            warning_flags
            -Wall
            # Disabled warnings:
            -Wno-switch
            -Wno-parentheses
            -Wno-unused-local-typedefs
            -Wno-class-memaccess
            -Wno-assume
            -Wno-reorder
            -Wno-invalid-offsetof
            -Wno-newline-eof
            -Wno-return-std-move
            # Allowed warnings:
            # If a function returns an address/reference to a local, we want it to
            # produce an error, because it probably means something very bad.
            -Werror=return-local-addr
            # Some warnings which are on by default in MSVC
            -Wnarrowing
        )
        if(ARG_USE_EXTRA_WARNINGS)
            list(APPEND warning_flags -Wextra)
        endif()
        if(ARG_USE_FEWER_WARNINGS)
            list(
                APPEND
                warning_flags
                -Wno-class-memaccess
                -Wno-unused-variable
                -Wno-unused-parameter
                -Wno-sign-compare
                -Wno-unused-function
                -Wno-unused-value
                -Wno-implicit-fallthrough
                -Wno-missing-field-initializers
                -Wno-strict-aliasing
                -Wno-maybe-uninitialized
            )
        endif()
    elseif(CMAKE_CXX_COMPILER_ID MATCHES "MSVC")
        list(APPEND warning_flags)
        if(ARG_USE_EXTRA_WARNINGS)
            list(APPEND warning_flags /W4)
        elseif(ARG_USE_FEWER_WARNINGS)
            list(APPEND warning_flags /W0)
        else()
            list(APPEND warning_flags /W2)
        endif()
    endif()

    add_supported_cxx_flags(${target} PRIVATE ${warning_flags})

    # Strip the absolute source directory prefix from __FILE__ so that build-machine
    # paths are not baked into the binary's read-only data section.
    #
    # On MSVC, /d1trimfile also rewrites source file paths in the PDB (not just
    # __FILE__), which breaks OpenCppCoverage on Windows coverage CI:
    # OCC's --sources filter is an absolute path and stops matching slang sources
    # once their PDB records become relative. Coverage builds are CI-only and
    # never shipped, so leaking dev paths into __FILE__ there is harmless --
    # skip the flag entirely when SLANG_ENABLE_COVERAGE is on.
    if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
        target_compile_options(
            ${target}
            PRIVATE "-fmacro-prefix-map=${CMAKE_SOURCE_DIR}/="
        )
    elseif(CMAKE_CXX_COMPILER_ID MATCHES "MSVC" AND NOT SLANG_ENABLE_COVERAGE)
        target_compile_options(
            ${target}
            PRIVATE "/d1trimfile:${CMAKE_SOURCE_DIR}\\"
        )
    endif()

    if(NOT WIN32)
        # these options are for ELF specific and not for Windows
        add_supported_cxx_linker_flags(
            ${target}
            PRIVATE
            # Don't assume that symbols will be resolved at runtime
            "-Wl,--no-undefined"
            # No reason not to do this? Useful when using split debug info
            "-Wl,--build-id"
        )
    endif()

    set_target_properties(
        ${target}
        PROPERTIES # -fvisibility=hidden
            CXX_VISIBILITY_PRESET
            hidden
            C_VISIBILITY_PRESET
            hidden
            VISIBILITY_INLINES_HIDDEN
            ON
            # C++ standard
            CXX_STANDARD
            20
            # pic
            POSITION_INDEPENDENT_CODE
            ON
    )

    target_compile_definitions(
        ${target}
        PRIVATE # Add _DEBUG depending on the build configuration
            $<$<CONFIG:Debug>:_DEBUG>
            # For including windows.h in a way that minimized namespace
            # pollution. Although we define these here, we still set them
            # manually in any header files which may be included by another
            # project
            WIN32_LEAN_AND_MEAN
            VC_EXTRALEAN
            NOMINMAX
            # Use multi-byte character set on Windows
            UNICODE
            _UNICODE
    )

    #
    # Settings dependent on config options
    #

    target_compile_definitions(
        ${target}
        PRIVATE
            SLANG_ENABLE_DXIL_SUPPORT=$<BOOL:${SLANG_ENABLE_DXIL}>
            SLANG_ENABLE_WEBGPU=$<BOOL:${SLANG_HAS_WEBGPU_SUPPORT}>
            SLANG_ENABLE_VALIDATION_VM_BYTECODE=$<BOOL:${SLANG_ENABLE_VALIDATION_VM_BYTECODE}>
            $<$<BOOL:${SLANG_ENABLE_FULL_DEBUG_VALIDATION}>:SLANG_ENABLE_FULL_IR_VALIDATION>
            $<$<BOOL:${SLANG_ENABLE_IR_BREAK_ALLOC}>:SLANG_ENABLE_IR_BREAK_ALLOC>
            $<$<BOOL:${SLANG_ENABLE_DX_ON_VK}>:SLANG_CONFIG_DX_ON_VK>
            $<$<STREQUAL:${SLANG_LIB_TYPE},STATIC>:STB_IMAGE_STATIC>
    )

    if(SLANG_ENABLE_ASAN AND NOT ARG_SKIP_ASAN)
        # -fno-sanitize-recover=undefined is intentionally omitted so that
        # halt_on_error can be controlled at runtime via UBSAN_OPTIONS.
        # For abort-on-first-UB locally, set UBSAN_OPTIONS=halt_on_error=1.
        if(CMAKE_CXX_COMPILER_ID MATCHES "Clang")
            target_compile_options(
                ${target}
                PRIVATE
                    -fsanitize=address
                    -fsanitize=undefined
                    -fsanitize-ignorelist=${PROJECT_SOURCE_DIR}/cmake/sanitizer-ignorelist.txt
            )
            target_link_options(
                ${target}
                BEFORE
                PRIVATE -fsanitize=address -fsanitize=undefined
            )
            if(NOT APPLE)
                # Clang defaults to statically linking the sanitizer runtime,
                # which is not compatible with `-Wl,--no-undefined`, so we need
                # to use dynamic linking instead (`-shared-libsan`).
                # On macOS/Darwin the sanitizer runtime is already dynamic.
                target_compile_options(${target} PRIVATE -shared-libsan)
                target_link_options(${target} BEFORE PRIVATE -shared-libsan)
            endif()
        elseif(CMAKE_CXX_COMPILER_ID MATCHES "GNU")
            target_compile_options(
                ${target}
                PRIVATE -fsanitize=address -fsanitize=undefined
            )
            target_link_options(
                ${target}
                BEFORE
                PRIVATE -fsanitize=address -fsanitize=undefined
            )
        elseif(CMAKE_CXX_COMPILER_ID MATCHES "MSVC")
            target_compile_options(${target} PRIVATE /fsanitize=address)
            target_link_options(${target} BEFORE PRIVATE /INCREMENTAL:NO)
        else()
            message(FATAL_ERROR "SLANG_ENABLE_ASAN: unsupported C++ compiler")
        endif()
    endif()

    if(SLANG_ENABLE_COVERAGE)
        if(CMAKE_CXX_COMPILER_ID MATCHES "Clang")
            # Clang source-based coverage: both flags required together for
            # source mapping to work
            target_compile_options(
                ${target}
                PRIVATE -fprofile-instr-generate -fcoverage-mapping
            )
            target_link_options(
                ${target}
                BEFORE
                PUBLIC -fprofile-instr-generate
            )
        elseif(CMAKE_CXX_COMPILER_ID MATCHES "GNU")
            # GCC gcov-based coverage
            target_compile_options(${target} PRIVATE --coverage)
            target_link_options(${target} BEFORE PUBLIC --coverage)
        elseif(CMAKE_CXX_COMPILER_ID MATCHES "MSVC")
            # MSVC has no native source-level coverage tool; Windows coverage
            # is collected externally by OpenCppCoverage via PDBs. The only
            # build-time tuning that matters is keeping more of the source
            # visible in the PDB. CMake's default RelWithDebInfo flags are
            # `/O2 /Ob1`, which already downgrades inlining from /Ob2 but
            # still inlines any function marked `inline` or `__inline`
            # (covering most header-defined methods in Slang). /Ob0
            # disables inlining entirely so every function body remains
            # distinct in the binary, giving a truthful hit/miss verdict
            # for every source line. Runtime is ~2-3x slower -- acceptable
            # for a nightly coverage job where accuracy is the target.
            # (MSVC emits D9025 "overriding '/Ob1' with '/Ob0'" -- harmless
            # noise; /wd9025 can't suppress driver warnings, so we just live
            # with it.)
            target_compile_options(${target} PRIVATE /Ob0)
            # Force /INCREMENTAL:NO at the target level. Windows +
            # Ninja-Multi-Config + RelWithDebInfo otherwise leaves
            # /INCREMENTAL on the link line (CMake's default for the
            # configuration), racing with slang-proxy's explicit
            # /INCREMENTAL:NO and producing LNK1104 on slang.ilk. Disabling
            # incremental linking globally for coverage targets avoids the
            # .ilk file entirely. No runtime cost.
            target_link_options(${target} PRIVATE /INCREMENTAL:NO)
        endif()
    endif()

    if(SLANG_ENABLE_TIME_TRACE)
        # Time trace profiling for Clang (use with ClangBuildAnalyzer)
        if(CMAKE_CXX_COMPILER_ID MATCHES "Clang")
            target_compile_options(${target} PRIVATE -ftime-trace)
        endif()
    endif()
endfunction()
