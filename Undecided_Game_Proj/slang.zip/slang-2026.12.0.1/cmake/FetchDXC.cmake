# FetchDXC.cmake
#
# Fetches DXC (DirectXShaderCompiler) prebuilt binaries via FetchContent and
# copies them to the build output directory.
#
# On Linux, the prebuilt binary is downloaded at Slang configure time to detect
# the actual GLIBC version it requires. Both libdxcompiler.so and libdxil.so are
# inspected; if either requires a newer GLIBC than the system provides, DXC is
# built from source instead. The source build also runs cmake-configuration at
# Slang configure time so build-time surprises are avoided.
#
# All configure-time downloads and inspections are cached with stamp files so
# that subsequent cmake reconfigures skip them.
#
# Variables:
#   SLANG_DXC_BINARY_URL        - Override the prebuilt binary download URL
#                                 (optional; skips auto-detection when set)
#   SLANG_DXC_BUILD_FROM_SOURCE - ON: build from source when supported; OFF:
#                                 always use prebuilt when available (skips detection);
#                                 unset: build from source on macOS; auto-detect
#                                 on native Linux x86_64 by downloading the
#                                 prebuilt binary and inspecting the GLIBC
#                                 requirements of both libdxcompiler.so and
#                                 libdxil.so
#   SLANG_GITHUB_TOKEN          - GitHub token for authenticated downloads (optional)
#
# Requires the following variables to be set by the caller (set in SlangTarget.cmake):
#   runtime_subdir   - Destination for Windows DLLs (e.g. "bin")
#   library_subdir   - Destination for Unix shared libraries (e.g. "lib")

include(FetchContent)

# DXC release metadata.
#
# To upgrade DXC:
#   1. Pick a release tag from
#      https://github.com/microsoft/DirectXShaderCompiler/releases.
#   2. Set _dxc_version_tag to that tag.
#   3. Set _dxc_release_date to the date used in the release asset names:
#      dxc_<YYYY_MM_DD>.zip and linux_dxc_<YYYY_MM_DD>.x86_64.tar.gz.
#   4. Resolve the release tag to the source commit used by source builds:
#      git ls-remote https://github.com/microsoft/DirectXShaderCompiler.git \
#          "refs/tags/<tag>" "refs/tags/<tag>^{}"
#      For an annotated tag, use the peeled ^{} hash. Otherwise use the tag hash.
#   5. Download the Windows zip and Linux tarball, then update the hashes with:
#      sha256sum dxc_<YYYY_MM_DD>.zip linux_dxc_<YYYY_MM_DD>.x86_64.tar.gz
#   6. Keep external/slang-rhi/CMakeLists.txt's SLANG_RHI_DXC_URL in sync with
#      the Windows DXC URL below.
set(_dxc_version_tag "v1.9.2602")
set(_dxc_expected_git_commit "21d28f727ad395b59394815ef76012e432f7e4e5")
set(_dxc_release_date "2026_02_20")
set(_dxc_windows_sha256
    "a1e89031421cf3c1fca6627766ab3020ca4f962ac7e2caa7fab2b33a8436151e"
)
set(_dxc_linux_sha256
    "a1d3e3b5e1c5685b3eb27d5e8890e41d87df45def05112a2d6f1a63a931f7d60"
)
set(_dxc_windows_url_hash "SHA256=${_dxc_windows_sha256}")
set(_dxc_linux_url_hash "SHA256=${_dxc_linux_sha256}")

set(_dxc_has_custom_binary_url OFF)
if(DEFINED SLANG_DXC_BINARY_URL AND NOT SLANG_DXC_BINARY_URL STREQUAL "")
    set(_dxc_has_custom_binary_url ON)
endif()

function(_dxc_stage_hlsl_headers dxc_root dxc_origin)
    set(_dxc_header_deps "${ARGN}")

    # Stage public DXC HLSL headers (e.g. dx/linalg.h) at a stable path so test
    # directives and local `slangc -Xdxc -Ibuild/dxc/include` invocations can
    # resolve them. Done as a build-graph custom command, matching the DXC
    # runtime copy pattern below.
    if(EXISTS "${dxc_root}/include/hlsl/dx/linalg.h")
        set(_dxc_hlsl_include_dir "${dxc_root}/include/hlsl")
    elseif(EXISTS "${dxc_root}/inc/hlsl/dx/linalg.h")
        set(_dxc_hlsl_include_dir "${dxc_root}/inc/hlsl")
    elseif(EXISTS "${dxc_root}/tools/clang/lib/Headers/hlsl/dx/linalg.h")
        set(_dxc_hlsl_include_dir "${dxc_root}/tools/clang/lib/Headers/hlsl")
    else()
        if(SLANG_ENABLE_TESTS)
            message(
                FATAL_ERROR
                "DXC ${dxc_origin} at ${dxc_root} is missing dx/linalg.h. "
                "The cooperative-{vector,matrix} tests rely on this header. "
                "If Microsoft has reorganized the layout, update FetchDXC.cmake."
            )
        endif()
        message(
            WARNING
            "DXC ${dxc_origin} at ${dxc_root} is missing dx/linalg.h. "
            "Skipping staged DXC HLSL headers because SLANG_ENABLE_TESTS is "
            "disabled. DXIL cooperative-{vector,matrix} local builds that pass "
            "-Xdxc -Ibuild/dxc/include will need an external DXC include path."
        )
        add_custom_target(stage-dxc-headers)
        set_target_properties(stage-dxc-headers PROPERTIES FOLDER generated)
        return()
    endif()

    set(_dxc_inc_src "${_dxc_hlsl_include_dir}/dx/linalg.h")
    set(_dxc_inc_dst "${CMAKE_BINARY_DIR}/dxc/include/dx/linalg.h")
    list(PREPEND _dxc_header_deps "${_dxc_inc_src}")
    add_custom_command(
        OUTPUT "${_dxc_inc_dst}"
        COMMAND
            ${CMAKE_COMMAND} -E copy_directory "${_dxc_hlsl_include_dir}"
            "${CMAKE_BINARY_DIR}/dxc/include"
        DEPENDS ${_dxc_header_deps}
        VERBATIM
    )
    add_custom_target(stage-dxc-headers DEPENDS "${_dxc_inc_dst}")
    set_target_properties(stage-dxc-headers PROPERTIES FOLDER generated)
endfunction()

# ---------------------------------------------------------------------------
# Decide whether to build DXC from source.
# ---------------------------------------------------------------------------

set(_dxc_build_from_source OFF)

if(SLANG_DXC_BUILD_FROM_SOURCE)
    # User explicitly requested a source build.
    if(
        CMAKE_SYSTEM_NAME STREQUAL "Windows"
        OR CMAKE_SYSTEM_NAME STREQUAL "Linux"
        OR CMAKE_SYSTEM_NAME STREQUAL "Darwin"
    )
        set(_dxc_build_from_source ON)
    else()
        message(
            WARNING
            "SLANG_DXC_BUILD_FROM_SOURCE=ON is not supported on "
            "${CMAKE_SYSTEM_NAME}. DXC will be unavailable."
        )
        return()
    endif()
elseif(
    NOT DEFINED SLANG_DXC_BUILD_FROM_SOURCE
    AND CMAKE_SYSTEM_NAME STREQUAL "Darwin"
    AND NOT _dxc_has_custom_binary_url
)
    message(
        STATUS
        "SLANG_DXC_BUILD_FROM_SOURCE is unset on macOS; building DXC from "
        "source (${_dxc_version_tag})."
    )
    set(_dxc_build_from_source ON)
elseif(CMAKE_SYSTEM_NAME STREQUAL "Linux" AND CMAKE_CROSSCOMPILING)
    if(_dxc_has_custom_binary_url)
        message(
            STATUS
            "Cross-compiling for Linux: GLIBC auto-detection is skipped; "
            "using custom prebuilt DXC URL."
        )
    elseif(CMAKE_SYSTEM_PROCESSOR MATCHES "x86_64|amd64|AMD64")
        # Cross-compiling for Linux x86_64: the host cannot probe the target
        # system's GLIBC at configure time, so detection is skipped and the
        # prebuilt binary is used as-is. Inform the user so they can opt in to
        # a source build if the target GLIBC is older than the prebuilt requires.
        message(
            STATUS
            "Cross-compiling for Linux x86_64: GLIBC auto-detection is skipped "
            "(cannot probe the target system at configure time). "
            "Set -DSLANG_DXC_BUILD_FROM_SOURCE=ON if the target GLIBC is older "
            "than the prebuilt DXC binary requires."
        )
    else()
        message(
            WARNING
            "Cross-compiling for Linux ${CMAKE_SYSTEM_PROCESSOR}: no default "
            "prebuilt DXC binary is available. Set "
            "-DSLANG_DXC_BUILD_FROM_SOURCE=ON to build DXC from source, or "
            "-DSLANG_DXC_BINARY_URL=<url> to use a custom prebuilt binary."
        )
        return()
    endif()
elseif(
    DEFINED SLANG_DXC_BUILD_FROM_SOURCE
    AND NOT SLANG_DXC_BUILD_FROM_SOURCE
    AND CMAKE_SYSTEM_NAME STREQUAL "Linux"
    AND NOT CMAKE_CROSSCOMPILING
    AND NOT _dxc_has_custom_binary_url
    AND CMAKE_SYSTEM_PROCESSOR MATCHES "x86_64|amd64|AMD64"
)
    # User explicitly disabled the source build on x86_64 Linux; skip
    # auto-detection and use prebuilt binaries without any GLIBC check.
    # Non-x86_64 Linux falls through to the dedicated architecture warning
    # below (no prebuilt binary exists for those architectures).
    message(
        STATUS
        "SLANG_DXC_BUILD_FROM_SOURCE=OFF: using prebuilt DXC without "
        "GLIBC compatibility check — prebuilt binaries may fail to load "
        "if the system GLIBC is older than required."
    )
elseif(
    CMAKE_SYSTEM_NAME STREQUAL "Linux"
    AND NOT CMAKE_CROSSCOMPILING
    AND _dxc_has_custom_binary_url
)
    # User supplied a custom URL; skip GLIBC auto-detection and use it as-is.
    message(
        STATUS
        "SLANG_DXC_BINARY_URL set: skipping GLIBC auto-detection, "
        "using custom prebuilt URL."
    )
elseif(
    NOT DEFINED SLANG_DXC_BUILD_FROM_SOURCE
    AND CMAKE_SYSTEM_NAME STREQUAL "Linux"
    AND NOT CMAKE_CROSSCOMPILING
    AND NOT _dxc_has_custom_binary_url
    AND CMAKE_SYSTEM_PROCESSOR MATCHES "x86_64|amd64|AMD64"
)
    # Auto-detect: download the prebuilt Linux binary and inspect both
    # libdxcompiler.so and libdxil.so to find the highest GLIBC version they
    # require across both libraries. Compare that against the system GLIBC; if
    # the system is too old for either library, fall back to a source build.
    #
    # All steps are cached via stamp files so subsequent reconfigures are fast.

    set(_dxc_probe_url
        "https://github.com/microsoft/DirectXShaderCompiler/releases/download/${_dxc_version_tag}/linux_dxc_${_dxc_release_date}.x86_64.tar.gz"
    )
    set(_dxc_probe_dir "${CMAKE_BINARY_DIR}/_dxc_probe")
    # Include the version tag in the filename so that bumping _dxc_version_tag
    # invalidates the cached tarball and forces a fresh download rather than
    # re-using a stale archive from a previous version.
    set(_dxc_probe_tarball "${_dxc_probe_dir}/dxc_${_dxc_version_tag}.tar.gz")
    # Stamp stores the highest GLIBC version required across both .so files
    # (e.g. "2.34"). Failed detections are intentionally not cached so transient
    # download/tooling issues are retried on the next reconfigure.
    set(_dxc_glibc_stamp "${_dxc_probe_dir}/req_glibc_${_dxc_version_tag}.txt")

    set(_dxc_required_glibc "0.0")
    if(EXISTS "${_dxc_glibc_stamp}")
        file(READ "${_dxc_glibc_stamp}" _dxc_required_glibc)
        string(STRIP "${_dxc_required_glibc}" _dxc_required_glibc)
        if(_dxc_required_glibc STREQUAL "DETECTION_FAILED")
            message(
                STATUS
                "Discarding stale DXC GLIBC detection failure stamp; "
                "retrying detection for ${_dxc_version_tag}."
            )
            file(REMOVE "${_dxc_glibc_stamp}")
            set(_dxc_required_glibc "0.0")
        endif()
    endif()

    if(NOT EXISTS "${_dxc_glibc_stamp}")
        file(MAKE_DIRECTORY "${_dxc_probe_dir}")

        # Download the tarball once; reused by FetchContent for the actual
        # binary deployment if the system GLIBC turns out to be new enough.
        if(EXISTS "${_dxc_probe_tarball}")
            file(SHA256 "${_dxc_probe_tarball}" _dxc_probe_sha256)
            if(NOT _dxc_probe_sha256 STREQUAL _dxc_linux_sha256)
                message(
                    STATUS
                    "Cached DXC prebuilt binary failed hash verification; "
                    "re-downloading ${_dxc_version_tag}."
                )
                file(REMOVE "${_dxc_probe_tarball}")
            endif()
        endif()

        if(NOT EXISTS "${_dxc_probe_tarball}")
            message(
                STATUS
                "Downloading DXC prebuilt binary to detect GLIBC requirement..."
            )
            set(_dl_headers "")
            if(SLANG_GITHUB_TOKEN)
                set(_dl_headers
                    HTTPHEADER
                    "Authorization: token ${SLANG_GITHUB_TOKEN}"
                )
            endif()
            file(
                DOWNLOAD "${_dxc_probe_url}" "${_dxc_probe_tarball}"
                STATUS _dl_status
                EXPECTED_HASH "${_dxc_linux_url_hash}"
                SHOW_PROGRESS
                ${_dl_headers}
            )
            list(GET _dl_status 0 _dl_code)
            if(NOT _dl_code EQUAL 0)
                list(GET _dl_status 1 _dl_msg)
                message(
                    WARNING
                    "Failed to download DXC prebuilt binary: ${_dl_msg}. "
                    "Building DXC from source instead."
                )
                file(REMOVE "${_dxc_probe_tarball}")
                set(_dxc_build_from_source ON)
            endif()
        endif()

        if(EXISTS "${_dxc_probe_tarball}" AND NOT _dxc_build_from_source)
            # Extract only the two shared libraries that determine runtime
            # compatibility; avoids unpacking the full ~30 MB tarball.
            execute_process(
                COMMAND
                    ${CMAKE_COMMAND} -E tar xzf "${_dxc_probe_tarball}"
                    lib/libdxcompiler.so lib/libdxil.so
                WORKING_DIRECTORY "${_dxc_probe_dir}"
                RESULT_VARIABLE _tar_result
                OUTPUT_QUIET
                ERROR_VARIABLE _tar_error
            )
            if(NOT _tar_result EQUAL 0)
                message(
                    WARNING
                    "Failed to extract shared libraries from DXC prebuilt "
                    "tarball (exit ${_tar_result}): ${_tar_error}. "
                    "Building DXC from source instead."
                )
                # Remove the tarball so a fresh download is attempted on the
                # next reconfigure rather than retrying with a bad archive.
                file(REMOVE "${_dxc_probe_tarball}")
                set(_dxc_build_from_source ON)
            else()
                find_program(_dxc_objdump NAMES objdump)
                find_program(_dxc_readelf NAMES readelf)

                # Inspect each library and track the highest GLIBC version found
                # across both. If either library requires GLIBC X.Y, the system
                # must provide at least X.Y for both to load.
                foreach(_lib libdxcompiler.so libdxil.so)
                    set(_so "${_dxc_probe_dir}/lib/${_lib}")
                    if(NOT EXISTS "${_so}")
                        continue()
                    endif()
                    set(_elf_info "")
                    if(_dxc_objdump)
                        execute_process(
                            COMMAND "${_dxc_objdump}" -p "${_so}"
                            OUTPUT_VARIABLE _elf_info
                            ERROR_QUIET
                        )
                    elseif(_dxc_readelf)
                        execute_process(
                            COMMAND "${_dxc_readelf}" --version-info "${_so}"
                            OUTPUT_VARIABLE _elf_info
                            ERROR_QUIET
                        )
                    endif()
                    string(
                        REGEX MATCHALL
                        "GLIBC_([0-9]+[.][0-9]+)"
                        _ver_list
                        "${_elf_info}"
                    )
                    foreach(_entry ${_ver_list})
                        string(REGEX REPLACE "^GLIBC_" "" _ver "${_entry}")
                        if(_ver VERSION_GREATER _dxc_required_glibc)
                            set(_dxc_required_glibc "${_ver}")
                        endif()
                    endforeach()
                endforeach()

                if(NOT _dxc_required_glibc STREQUAL "0.0")
                    message(
                        STATUS
                        "DXC prebuilt binary (${_dxc_version_tag}) "
                        "requires GLIBC >= ${_dxc_required_glibc}"
                    )
                    file(WRITE "${_dxc_glibc_stamp}" "${_dxc_required_glibc}")
                else()
                    message(
                        WARNING
                        "Could not extract GLIBC version requirements from DXC "
                        "shared libraries (objdump/readelf unavailable or produced "
                        "no output). Building DXC from source instead; detection "
                        "will be retried on the next reconfigure."
                    )
                    set(_dxc_build_from_source ON)
                endif()
            endif() # else() of tar extraction success check
        endif()
    endif()

    # Compare the detected requirement against the system GLIBC.
    if(NOT _dxc_build_from_source AND NOT _dxc_required_glibc STREQUAL "0.0")
        execute_process(
            COMMAND getconf GNU_LIBC_VERSION
            OUTPUT_VARIABLE _libc_probe
            OUTPUT_STRIP_TRAILING_WHITESPACE
            ERROR_QUIET
            RESULT_VARIABLE _getconf_result
        )
        if(NOT _getconf_result EQUAL 0)
            execute_process(
                COMMAND ldd --version
                OUTPUT_VARIABLE _libc_probe
                ERROR_VARIABLE _libc_probe_stderr
                OUTPUT_STRIP_TRAILING_WHITESPACE
                ERROR_STRIP_TRAILING_WHITESPACE
            )
            # Some distributions (e.g. older CentOS/RHEL) print the version
            # to stderr rather than stdout; fall back to stderr when stdout
            # is empty.
            if(NOT _libc_probe)
                set(_libc_probe "${_libc_probe_stderr}")
            endif()
        endif()
        # Detect musl libc before attempting the glibc regex: prebuilt DXC
        # binaries are glibc-linked and will definitely not load on musl
        # systems, so force a source build immediately.
        if(_libc_probe MATCHES "[Mm]usl" OR EXISTS "/lib/ld-musl-x86_64.so.1")
            message(
                STATUS
                "Detected musl libc; prebuilt DXC binaries require glibc "
                "and will not load. Building DXC from source "
                "(${_dxc_version_tag})."
            )
            set(_dxc_build_from_source ON)
        else()
            string(
                REGEX MATCH
                "[Gg][Ll][Ii][Bb][Cc][^0-9]*([0-9]+)\\.([0-9]+)"
                _glibc_match
                "${_libc_probe}"
            )
            if(_glibc_match)
                set(_glibc_version "${CMAKE_MATCH_1}.${CMAKE_MATCH_2}")
                message(
                    STATUS
                    "Detected system GLIBC version: ${_glibc_version}"
                )
                if(_glibc_version VERSION_LESS _dxc_required_glibc)
                    message(
                        STATUS
                        "System GLIBC ${_glibc_version} < required "
                        "${_dxc_required_glibc}: building DXC from source "
                        "(${_dxc_version_tag})"
                    )
                    set(_dxc_build_from_source ON)
                endif()
            else()
                message(
                    WARNING
                    "Could not detect system GLIBC version (getconf and ldd "
                    "both failed or produced unrecognisable output). "
                    "Building DXC from source instead."
                )
                set(_dxc_build_from_source ON)
            endif()
        endif()
    endif()
elseif(
    CMAKE_SYSTEM_NAME STREQUAL "Linux"
    AND NOT CMAKE_CROSSCOMPILING
    AND NOT _dxc_has_custom_binary_url
    AND NOT CMAKE_SYSTEM_PROCESSOR MATCHES "x86_64|amd64|AMD64"
)
    # Non-x86_64 Linux: no prebuilt binary is available for this architecture.
    # Do not implicitly trigger a source build here; it is expensive and is not
    # part of the default Linux ARM64 build. Users can still opt in explicitly
    # with SLANG_DXC_BUILD_FROM_SOURCE=ON, which is handled by the first branch.
    if(DEFINED SLANG_DXC_BUILD_FROM_SOURCE AND NOT SLANG_DXC_BUILD_FROM_SOURCE)
        message(
            WARNING
            "SLANG_DXC_BUILD_FROM_SOURCE=OFF but no prebuilt DXC binary is "
            "available for ${CMAKE_SYSTEM_PROCESSOR} on Linux. "
            "DXC will be unavailable. "
            "Set -DSLANG_DXC_BUILD_FROM_SOURCE=ON to build DXC from source, "
            "or set -DSLANG_DXC_BINARY_URL=<url> to use a custom prebuilt binary."
        )
    else()
        message(
            WARNING
            "No prebuilt DXC binary is available for ${CMAKE_SYSTEM_PROCESSOR} "
            "on Linux. DXC will be unavailable. "
            "Set -DSLANG_DXC_BUILD_FROM_SOURCE=ON to build DXC from source, "
            "or set -DSLANG_DXC_BINARY_URL=<url> to use a custom prebuilt binary."
        )
    endif()
    return()
endif()

# ---------------------------------------------------------------------------
# Source build: clone and cmake-configure at Slang configure time.
# ---------------------------------------------------------------------------

if(_dxc_build_from_source)
    set(_dxc_forwarded_config_args "")
    if(CMAKE_SYSTEM_NAME STREQUAL "Darwin")
        foreach(
            _dxc_osx_var
            CMAKE_OSX_ARCHITECTURES
            CMAKE_OSX_SYSROOT
            CMAKE_OSX_DEPLOYMENT_TARGET
        )
            if(DEFINED ${_dxc_osx_var} AND NOT "${${_dxc_osx_var}}" STREQUAL "")
                set(_dxc_osx_value "${${_dxc_osx_var}}")
                string(REPLACE ";" "\\;" _dxc_osx_value "${_dxc_osx_value}")
                list(
                    APPEND
                    _dxc_forwarded_config_args
                    "-D${_dxc_osx_var}=${_dxc_osx_value}"
                )
            endif()
        endforeach()
    endif()

    # DXC's build (PredefinedParams.cmake) is designed for a single-config
    # generator. Normalize any Ninja variant (e.g. "Ninja Multi-Config") to
    # plain "Ninja"; for non-Ninja generators (e.g. Visual Studio on Windows)
    # mirror the parent so the same toolchain is used.
    #
    # LLVM uses CMAKE_CFG_INTDIR (e.g. "." for Ninja, "$(Configuration)" for VS)
    # to set LLVM_RUNTIME_OUTPUT_INTDIR and LLVM_LIBRARY_OUTPUT_INTDIR, so for
    # multi-config generators the artifacts land under MinSizeRel. Track these
    # subdirectories so byproducts and copy commands point to the right path.
    get_property(
        _dxc_parent_is_multi_config
        GLOBAL
        PROPERTY GENERATOR_IS_MULTI_CONFIG
    )
    if(CMAKE_GENERATOR MATCHES "Ninja")
        set(_dxc_generator_args -G Ninja)
        set(_dxc_inner_is_multi_config OFF)
    else()
        set(_dxc_generator_args -G "${CMAKE_GENERATOR}")
        if(CMAKE_GENERATOR_PLATFORM)
            list(APPEND _dxc_generator_args -A "${CMAKE_GENERATOR_PLATFORM}")
        endif()
        if(CMAKE_GENERATOR_TOOLSET)
            list(APPEND _dxc_generator_args -T "${CMAKE_GENERATOR_TOOLSET}")
        endif()
        set(_dxc_inner_is_multi_config "${_dxc_parent_is_multi_config}")
    endif()

    if(_dxc_inner_is_multi_config)
        set(_dxc_dll_subdir "MinSizeRel/bin")
        set(_dxc_lib_subdir "MinSizeRel/lib")
    else()
        set(_dxc_dll_subdir "bin")
        set(_dxc_lib_subdir "lib")
    endif()

    # Step 1: Clone DXC source at Slang configure time.
    # FetchContent stamps ensure the clone is skipped on subsequent reconfigures.
    # DXC includes LLVM/Clang as submodules; the first clone can take
    # 10–30 minutes depending on network speed, and the subsequent build
    # adds another 10–30 minutes. Subsequent reconfigures and incremental
    # builds skip both steps via stamp files and add_custom_command OUTPUT
    # tracking.
    message(
        STATUS
        "Cloning DXC ${_dxc_version_tag} from source "
        "(first run: ~500 MB download + 10-30 min build; "
        "subsequent runs are skipped via stamp files)..."
    )
    FetchContent_Declare(
        dxc_source
        GIT_REPOSITORY "https://github.com/microsoft/DirectXShaderCompiler.git"
        GIT_TAG "${_dxc_version_tag}"
        GIT_SHALLOW ON
        GIT_SUBMODULES_RECURSE ON
        GIT_PROGRESS ON
        UPDATE_DISCONNECTED ON
        SOURCE_SUBDIR
        _does_not_exist_
    )
    FetchContent_MakeAvailable(dxc_source)
    set(_dxc_src_dir "${dxc_source_SOURCE_DIR}")
    set(_dxc_build_dir "${dxc_source_BINARY_DIR}")
    find_package(Git REQUIRED)
    execute_process(
        COMMAND "${GIT_EXECUTABLE}" -C "${_dxc_src_dir}" rev-parse HEAD
        RESULT_VARIABLE _dxc_rev_parse_result
        OUTPUT_VARIABLE _dxc_actual_git_commit
        OUTPUT_STRIP_TRAILING_WHITESPACE
        ERROR_QUIET
    )
    if(
        NOT _dxc_rev_parse_result EQUAL 0
        OR NOT _dxc_actual_git_commit STREQUAL _dxc_expected_git_commit
    )
        message(
            FATAL_ERROR
            "DXC tag ${_dxc_version_tag} resolved to ${_dxc_actual_git_commit}, "
            "expected ${_dxc_expected_git_commit}. Update FetchDXC.cmake only "
            "after verifying the new DXC source revision."
        )
    endif()

    # If HLSL_COPY_GENERATED_SOURCES were ever re-enabled, DXC's build would run
    # clang-format on generated files and walk up to find .clang-format. Slang's
    # root .clang-format uses options unsupported by older clang-format versions,
    # so we place DXC's own style here to stop the upward search at the right level.
    file(MAKE_DIRECTORY "${_dxc_build_dir}")
    file(WRITE "${_dxc_build_dir}/.clang-format" "BasedOnStyle: LLVM\n")

    # Step 2: Configure DXC at Slang configure time.
    #
    # _dxc_configure_args is the single source of truth for the configure
    # invocation: it is used both to compute the stamp hash below and to run the
    # configure itself. Because the stamp hashes the exact argument list, any
    # change to the configure command (flags, compilers, generator, build type,
    # forwarded args) automatically invalidates the stamp and forces a
    # reconfigure. That reconfigure rewrites the stamp, which in turn cascades
    # into a rebuild via the configure-stamp DEPENDS edge on the DXC build
    # custom command. This keeps a stale configuration from silently surviving a
    # flag change (e.g. the -Wno-invalid-specialization workaround below).
    set(_dxc_configure_args
        -B
        "${_dxc_build_dir}"
        -S
        "${_dxc_src_dir}"
        ${_dxc_generator_args}
        -C
        "${_dxc_src_dir}/cmake/caches/PredefinedParams.cmake"
        # Forward parent compilers so DXC uses the same toolchain.
        "-DCMAKE_C_COMPILER=${CMAKE_C_COMPILER}"
        "-DCMAKE_CXX_COMPILER=${CMAKE_CXX_COMPILER}"
        # CMAKE_BUILD_TYPE is ignored by multi-config generators (VS); the
        # config is selected via --config MinSizeRel in the build command.
        # Passing it here covers single-config generators (Ninja).
        -DCMAKE_BUILD_TYPE=MinSizeRel
        -DHLSL_COPY_GENERATED_SOURCES=OFF
        -DLLVM_INCLUDE_TESTS=OFF
        -DCLANG_INCLUDE_TESTS=OFF
        -DLLVM_ENABLE_WARNINGS=OFF
        ${_dxc_forwarded_config_args}
        -Wno-dev
    )

    # Apple Clang 21+ (Xcode 26+) ships a libc++ that marks
    # std::is_nothrow_constructible with [[_Clang::__no_specializations__]],
    # turning DXC's LLVM StringRef trait specializations into
    # -Winvalid-specialization hard errors. Only this toolchain needs the
    # suppression, so scope it to AppleClang >= 21; other compilers (and older
    # AppleClang) must not receive a flag they do not need.
    if(
        CMAKE_CXX_COMPILER_ID STREQUAL "AppleClang"
        AND CMAKE_CXX_COMPILER_VERSION VERSION_GREATER_EQUAL "21.0.0"
    )
        list(
            APPEND
            _dxc_configure_args
            "-DCMAKE_CXX_FLAGS=-Wno-invalid-specialization"
        )
    endif()

    # A SHA256 hash keeps the stamp content short regardless of argument length.
    # The leading "stamp-v1;" token is a manual schema version: bump it to force
    # every checkout to reconfigure DXC even when no configure argument changed.
    string(SHA256 _dxc_config_hash "stamp-v1;${_dxc_configure_args}")
    set(_dxc_configure_stamp "${_dxc_build_dir}/.slang_dxc_configured")
    set(_dxc_configure_is_current OFF)
    if(EXISTS "${_dxc_configure_stamp}")
        file(READ "${_dxc_configure_stamp}" _dxc_configure_stamp_content)
        string(
            STRIP
            "${_dxc_configure_stamp_content}"
            _dxc_configure_stamp_content
        )
        if(_dxc_configure_stamp_content STREQUAL _dxc_config_hash)
            set(_dxc_configure_is_current ON)
        endif()
    endif()
    file(
        GLOB _dxc_legacy_configure_stamps
        "${_dxc_build_dir}/.slang_dxc_configured_*"
    )
    if(_dxc_legacy_configure_stamps)
        file(REMOVE ${_dxc_legacy_configure_stamps})
    endif()
    if(NOT _dxc_configure_is_current)
        message(STATUS "Configuring DXC from source (${_dxc_version_tag})...")
        execute_process(
            COMMAND ${CMAKE_COMMAND} ${_dxc_configure_args}
            RESULT_VARIABLE _dxc_configure_result
            OUTPUT_VARIABLE _dxc_configure_output
            ERROR_VARIABLE _dxc_configure_error
        )
        if(NOT _dxc_configure_result EQUAL 0)
            message(
                WARNING
                "DXC cmake configure failed "
                "(exit ${_dxc_configure_result}). "
                "DXC/DXIL support will be unavailable. "
                "Set -DSLANG_DXC_BUILD_FROM_SOURCE=OFF to skip the source "
                "build, or fix the build environment.\n"
                "${_dxc_configure_output}\n${_dxc_configure_error}"
            )
            return()
        endif()
        file(WRITE "${_dxc_configure_stamp}" "${_dxc_config_hash}\n")
        message(STATUS "DXC configured successfully")
    endif()

    # Step 3: Build DXC at Slang build time.
    # The DXIL validator target is named 'dxildll' in DXC's CMake (it produces
    # dxil.dll on Windows and a shared library on Unix-like systems).
    if(CMAKE_GENERATOR MATCHES "Ninja")
        set(_dxc_build_cmd
            ${CMAKE_COMMAND}
            --build
            "${_dxc_build_dir}"
            --config
            MinSizeRel
            --target
            dxcompiler
            dxildll
        )
    else()
        set(_dxc_build_cmd
            ${CMAKE_COMMAND}
            --build
            "${_dxc_build_dir}"
            --config
            MinSizeRel
            --target
            dxcompiler
            --target
            dxildll
        )
    endif()

    if(CMAKE_SYSTEM_NAME STREQUAL "Windows")
        set(_dxc_src_byproducts
            "${_dxc_build_dir}/${_dxc_dll_subdir}/dxcompiler.dll"
            "${_dxc_build_dir}/${_dxc_dll_subdir}/dxil.dll"
        )
    else()
        set(_dxc_shared_library_prefix "${CMAKE_SHARED_LIBRARY_PREFIX}")
        set(_dxc_shared_library_suffix "${CMAKE_SHARED_LIBRARY_SUFFIX}")
        set(_dxc_dxcompiler_library_name
            "${_dxc_shared_library_prefix}dxcompiler${_dxc_shared_library_suffix}"
        )
        set(_dxc_dxil_library_name
            "${_dxc_shared_library_prefix}dxil${_dxc_shared_library_suffix}"
        )
        set(_dxc_src_byproducts
            "${_dxc_build_dir}/${_dxc_lib_subdir}/${_dxc_dxcompiler_library_name}"
            "${_dxc_build_dir}/${_dxc_lib_subdir}/${_dxc_dxil_library_name}"
        )
    endif()

    # Use add_custom_command(OUTPUT) rather than add_custom_target so the
    # inner DXC build is only re-invoked when the output libraries do not
    # exist. add_custom_target is always considered out-of-date and would
    # run cmake --build on every incremental Slang build.
    add_custom_command(
        OUTPUT ${_dxc_src_byproducts}
        COMMAND ${_dxc_build_cmd}
        DEPENDS "${_dxc_configure_stamp}"
        COMMENT "Building DXC ${_dxc_version_tag} from source"
        VERBATIM
    )
    add_custom_target(dxc_from_source DEPENDS ${_dxc_src_byproducts})

    if(CMAKE_SYSTEM_NAME STREQUAL "Windows")
        foreach(_dll dxcompiler dxil)
            set(_src "${_dxc_build_dir}/${_dxc_dll_subdir}/${_dll}.dll")
            set(_dst
                "${CMAKE_BINARY_DIR}/$<CONFIG>/${runtime_subdir}/${_dll}.dll"
            )
            add_custom_command(
                OUTPUT "${_dst}"
                COMMAND
                    ${CMAKE_COMMAND} -E copy_if_different "${_src}" "${_dst}"
                DEPENDS "${_src}"
                VERBATIM
            )
            add_custom_target(copy-${_dll} DEPENDS "${_dst}")
            set_target_properties(copy-${_dll} PROPERTIES FOLDER generated)
        endforeach()
    else()
        foreach(_lib dxcompiler dxil)
            set(_dxc_shared_library_name
                "${_dxc_shared_library_prefix}${_lib}${_dxc_shared_library_suffix}"
            )
            set(_src
                "${_dxc_build_dir}/${_dxc_lib_subdir}/${_dxc_shared_library_name}"
            )
            set(_dst
                "${CMAKE_BINARY_DIR}/$<CONFIG>/${library_subdir}/${_dxc_shared_library_name}"
            )
            add_custom_command(
                OUTPUT "${_dst}"
                COMMAND
                    ${CMAKE_COMMAND} -E copy_if_different "${_src}" "${_dst}"
                DEPENDS "${_src}"
                VERBATIM
            )
            add_custom_target(copy-${_lib} DEPENDS "${_dst}")
            set_target_properties(copy-${_lib} PROPERTIES FOLDER generated)
        endforeach()
    endif()

    _dxc_stage_hlsl_headers("${_dxc_src_dir}" "source tree")

    return()
endif()

# ---------------------------------------------------------------------------
# Prebuilt binary download path.
# ---------------------------------------------------------------------------

if(NOT _dxc_has_custom_binary_url)
    if(CMAKE_SYSTEM_NAME STREQUAL "Windows")
        set(SLANG_DXC_BINARY_URL
            "https://github.com/microsoft/DirectXShaderCompiler/releases/download/${_dxc_version_tag}/dxc_${_dxc_release_date}.zip"
        )
        set(_dxc_url_hash "${_dxc_windows_url_hash}")
    elseif(CMAKE_SYSTEM_NAME STREQUAL "Linux")
        if(CMAKE_SYSTEM_PROCESSOR MATCHES "x86_64|amd64|AMD64")
            set(_dxc_url_hash "${_dxc_linux_url_hash}")
            # Reuse the probe tarball already downloaded during GLIBC detection
            # to avoid fetching the same file twice.
            if(DEFINED _dxc_probe_tarball AND EXISTS "${_dxc_probe_tarball}")
                set(SLANG_DXC_BINARY_URL "file://${_dxc_probe_tarball}")
            else()
                set(SLANG_DXC_BINARY_URL
                    "https://github.com/microsoft/DirectXShaderCompiler/releases/download/${_dxc_version_tag}/linux_dxc_${_dxc_release_date}.x86_64.tar.gz"
                )
            endif()
        endif()
    endif()
endif()

if(NOT DEFINED SLANG_DXC_BINARY_URL OR SLANG_DXC_BINARY_URL STREQUAL "")
    return()
endif()

message(STATUS "Fetching DXC prebuilt binary from: ${SLANG_DXC_BINARY_URL} ...")
set(_dxc_prebuilt_stage_stamp "${CMAKE_BINARY_DIR}/dxc/.prebuilt-stage-stamp")
set(_dxc_prebuilt_stage_stamp_contents "${SLANG_DXC_BINARY_URL}\n")
if(DEFINED _dxc_url_hash)
    string(APPEND _dxc_prebuilt_stage_stamp_contents "${_dxc_url_hash}\n")
endif()
if(EXISTS "${_dxc_prebuilt_stage_stamp}")
    file(READ "${_dxc_prebuilt_stage_stamp}" _dxc_existing_prebuilt_stage_stamp)
else()
    set(_dxc_existing_prebuilt_stage_stamp "")
endif()
if(
    NOT _dxc_existing_prebuilt_stage_stamp
        STREQUAL
        _dxc_prebuilt_stage_stamp_contents
)
    file(MAKE_DIRECTORY "${CMAKE_BINARY_DIR}/dxc")
    file(
        WRITE
        "${_dxc_prebuilt_stage_stamp}"
        "${_dxc_prebuilt_stage_stamp_contents}"
    )
endif()
set(_dxc_fetch_args
    dxc
    URL
    "${SLANG_DXC_BINARY_URL}"
    SOURCE_SUBDIR
    _does_not_exist_
)
# URL_HASH only applies to the default URLs we ship; if the caller overrides
# SLANG_DXC_BINARY_URL we have no way to know its digest.
if(DEFINED _dxc_url_hash)
    list(APPEND _dxc_fetch_args URL_HASH "${_dxc_url_hash}")
endif()
FetchContent_Declare(${_dxc_fetch_args})

FetchContent_GetProperties(dxc)
if(NOT dxc_POPULATED)
    FetchContent_MakeAvailable(dxc)
endif()

_dxc_stage_hlsl_headers(
    "${dxc_SOURCE_DIR}"
    "archive"
    "${_dxc_prebuilt_stage_stamp}"
)

if(CMAKE_SYSTEM_NAME STREQUAL "Windows")
    if(CMAKE_SYSTEM_PROCESSOR MATCHES "aarch64|arm64|ARM64")
        set(_dxc_arch arm64)
    else()
        set(_dxc_arch x64)
    endif()
    foreach(_dll dxcompiler dxil)
        set(_src "${dxc_SOURCE_DIR}/bin/${_dxc_arch}/${_dll}.dll")
        set(_dst "${CMAKE_BINARY_DIR}/$<CONFIG>/${runtime_subdir}/${_dll}.dll")
        add_custom_command(
            OUTPUT "${_dst}"
            COMMAND ${CMAKE_COMMAND} -E copy_if_different "${_src}" "${_dst}"
            DEPENDS "${_src}" "${_dxc_prebuilt_stage_stamp}"
            VERBATIM
        )
        add_custom_target(copy-${_dll} DEPENDS "${_dst}")
        set_target_properties(copy-${_dll} PROPERTIES FOLDER generated)
    endforeach()
elseif(
    CMAKE_SYSTEM_NAME STREQUAL "Linux"
    OR CMAKE_SYSTEM_NAME STREQUAL "Darwin"
)
    set(_dxc_shared_library_prefix "${CMAKE_SHARED_LIBRARY_PREFIX}")
    set(_dxc_shared_library_suffix "${CMAKE_SHARED_LIBRARY_SUFFIX}")
    foreach(_lib dxcompiler dxil)
        set(_dxc_shared_library_name
            "${_dxc_shared_library_prefix}${_lib}${_dxc_shared_library_suffix}"
        )
        set(_src "${dxc_SOURCE_DIR}/lib/${_dxc_shared_library_name}")
        set(_dst
            "${CMAKE_BINARY_DIR}/$<CONFIG>/${library_subdir}/${_dxc_shared_library_name}"
        )
        add_custom_command(
            OUTPUT "${_dst}"
            COMMAND ${CMAKE_COMMAND} -E copy_if_different "${_src}" "${_dst}"
            DEPENDS "${_src}" "${_dxc_prebuilt_stage_stamp}"
            VERBATIM
        )
        add_custom_target(copy-${_lib} DEPENDS "${_dst}")
        set_target_properties(copy-${_lib} PROPERTIES FOLDER generated)
    endforeach()
endif()
